/*
 * joy_test.h
 *
 * Created: 10.09.2014 15:23:54
 *  Author: jonarnp
 */ 


#ifndef JOY_TEST_H_
#define JOY_TEST_H_

/*
Prints joystick position and direction
*/
void Test_joy();

#endif /* JOY_TEST_H_ */