/*
 * slider_test.h
 *
 * Created: 17.09.2014 09:31:26
 *  Author: boerikse
 */ 


#ifndef SLIDER_TEST_H_
#define SLIDER_TEST_H_

/*
Prints slider positions
*/
void Test_slider();

#endif /* SLIDER_TEST_H_ */