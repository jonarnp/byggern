/*
 * usart_test.h
 *
 * Created: 03.09.2014 14:51:34
 *  Author: boerikse
 */ 


#ifndef USART_TEST_H_
#define USART_TEST_H_

/*
Transmits data received on the USART0 port
*/
void USART_test(void);

#endif /* USART_TEST_H_ */